# ELITE BATTLE: OFFLINE — Unity 3D Battle Royale Starter

This is a **source-code starter**, not a finished commercial game or APK. It creates an original greybox 3D offline battle-royale prototype with basic AI bots, a safe zone, loot, health, shooting, and a simple HUD.

## Requirements
- Unity Hub and Unity Editor (Unity 2022.3 LTS or a compatible recent LTS version recommended).
- Android Build Support, Android SDK & NDK Tools, and OpenJDK for Android APK builds.
- If you only have an Android phone, you will need access to a computer or a trusted cloud PC/build service. Unity Editor does not normally run directly on Android phones.

## Install the source
1. Download and unzip this package.
2. In Unity Hub, create a new **3D Core** project.
3. Copy the package's `Assets/EliteBattle` folder into your new project's `Assets` folder.
4. Open Unity and wait for scripts to compile.
5. Select **Tools → Elite Battle → Create Prototype Scene**.
6. Open `Assets/EliteBattle/Scenes/Prototype.unity` and press Play.

## Prototype controls in the Editor
- WASD: move
- Mouse: look
- Left mouse button: fire
- R: reload
- Space: jump
- C: crouch

## Android build checklist
1. Install Android Build Support from Unity Hub.
2. Open Build Profiles / Build Settings and switch platform to Android.
3. Set orientation to Landscape.
4. Add `Assets/EliteBattle/Scenes/Prototype.unity` to the build scene list.
5. Build an APK for local testing.

## Honest status
- Included: C# source scripts and a Unity Editor scene-builder.
- Not included: compiled APK, final art/animation, polished touch joystick, sounds, optimized large map, online multiplayer, or store publication.
- The source has not been compiled or tested in a Unity Editor in this environment. The editor scene builder creates a basic touch joystick, look zone, and action buttons, but actual touch behavior and device performance still require testing on the target Android device. A zero-error guarantee would be dishonest without compiling and testing on the target Unity version and Android device.

This is an original game prototype inspired by battle-royale mechanics. It does not use Free Fire's proprietary assets, map, branding, or code.
