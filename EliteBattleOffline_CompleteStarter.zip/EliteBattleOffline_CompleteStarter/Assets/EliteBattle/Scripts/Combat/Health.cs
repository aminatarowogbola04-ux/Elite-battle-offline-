using System;
using UnityEngine;

namespace EliteBattle
{
    public class Health : MonoBehaviour
    {
        [Min(1f)] public float maxHealth = 100f;
        public float CurrentHealth { get; private set; }
        public bool IsDead { get; private set; }
        public event Action<Health> Died;
        public event Action<float, float> Changed;

        private void Awake() { CurrentHealth = maxHealth; }

        public void TakeDamage(float amount)
        {
            if (IsDead || amount <= 0f) return;
            CurrentHealth = Mathf.Max(0f, CurrentHealth - amount);
            Changed?.Invoke(CurrentHealth, maxHealth);
            if (CurrentHealth <= 0f)
            {
                IsDead = true;
                Died?.Invoke(this);
            }
        }

        public void Heal(float amount)
        {
            if (IsDead || amount <= 0f) return;
            CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + amount);
            Changed?.Invoke(CurrentHealth, maxHealth);
        }
    }
}
