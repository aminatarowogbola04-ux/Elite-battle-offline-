using UnityEngine;

namespace EliteBattle
{
    public class WeaponShooter : MonoBehaviour
    {
        public Camera aimCamera;
        public float damage = 25f;
        public float range = 150f;
        public int magazineSize = 30;
        public int reserveAmmo = 120;
        public float shotsPerSecond = 7f;
        public LayerMask hitMask = ~0;
        private int ammo;
        private float nextShotTime;
        public int AmmoInMagazine => ammo;
        public int ReserveAmmo => reserveAmmo;

        private void Awake()
        {
            ammo = magazineSize;
            if (aimCamera == null) aimCamera = Camera.main;
        }

        private void Update()
        {
            if (Application.isMobilePlatform)
            {
                if (MobileInput.FireHeld) FireOnce();
                if (MobileInput.ReloadPressed) { Reload(); MobileInput.ReloadPressed = false; }
                return;
            }
            if (Input.GetKeyDown(KeyCode.R)) Reload();
            if (Input.GetMouseButton(0)) FireOnce();
        }

        public void FireOnce()
        {
            if (Time.time < nextShotTime) return;
            if (ammo <= 0) { Reload(); return; }
            nextShotTime = Time.time + 1f / Mathf.Max(0.1f, shotsPerSecond);
            ammo--;
            if (aimCamera == null) return;
            if (Physics.Raycast(aimCamera.transform.position, aimCamera.transform.forward, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore))
            {
                Health targetHealth = hit.collider.GetComponentInParent<Health>();
                if (targetHealth != null && targetHealth.transform.root != transform.root) targetHealth.TakeDamage(damage);
                LootPickup loot = hit.collider.GetComponentInParent<LootPickup>();
                if (loot != null && loot.type == LootPickup.PickupType.Ammo)
                {
                    reserveAmmo += loot.amount;
                    Destroy(loot.gameObject);
                }
            }
        }

        public void Reload()
        {
            if (ammo >= magazineSize || reserveAmmo <= 0) return;
            int amount = Mathf.Min(magazineSize - ammo, reserveAmmo);
            ammo += amount;
            reserveAmmo -= amount;
        }

        public void AddAmmo(int amount) { reserveAmmo += Mathf.Max(0, amount); }
    }
}
