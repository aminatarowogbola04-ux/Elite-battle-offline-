using UnityEngine;

namespace EliteBattle
{
    [RequireComponent(typeof(Health))]
    public class BotAI : MonoBehaviour
    {
        public Transform target;
        public float detectionRange = 45f;
        public float attackRange = 22f;
        public float moveSpeed = 3.2f;
        public float damagePerShot = 7f;
        public float shotsPerSecond = 0.65f;
        private float nextShot;
        private Health health;

        private void Awake()
        {
            health = GetComponent<Health>();
            health.Died += OnDied;
        }

        private void Start()
        {
            if (target == null)
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player != null) target = player.transform;
            }
        }

        private void Update()
        {
            if (target == null || health.IsDead) return;
            Vector3 delta = target.position - transform.position;
            delta.y = 0f;
            float distance = delta.magnitude;
            if (distance > detectionRange) return;
            if (delta.sqrMagnitude > 0.01f)
            {
                Quaternion look = Quaternion.LookRotation(delta.normalized);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, Time.deltaTime * 4f);
            }
            if (distance > attackRange)
            {
                Vector3 step = delta.normalized * moveSpeed * Time.deltaTime;
                transform.position += step;
            }
            else if (Time.time >= nextShot)
            {
                nextShot = Time.time + 1f / Mathf.Max(0.1f, shotsPerSecond);
                Vector3 origin = transform.position + Vector3.up * 1.3f;
                Vector3 destination = target.position + Vector3.up * 1f;
                Vector3 direction = destination - origin;
                if (Physics.Raycast(origin, direction.normalized, out RaycastHit hit, attackRange, ~0, QueryTriggerInteraction.Ignore))
                {
                    Health playerHealth = hit.collider.GetComponentInParent<Health>();
                    if (playerHealth != null && playerHealth.transform.root == target.root) playerHealth.TakeDamage(damagePerShot);
                }
            }
        }

        private void OnDied(Health ignored) { Destroy(gameObject, 1.5f); }
    }
}
