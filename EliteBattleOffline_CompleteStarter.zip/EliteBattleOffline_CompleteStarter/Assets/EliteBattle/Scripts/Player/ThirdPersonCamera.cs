using UnityEngine;

namespace EliteBattle
{
    public class ThirdPersonCamera : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0.55f, 1.6f, -4.2f);
        public float smooth = 10f;
        public float pitch = 10f;
        public float sensitivity = 1f;

        public void AddLookInput(float deltaX, float deltaY)
        {
            if (target == null) return;
            target.Rotate(0f, deltaX * sensitivity, 0f);
            pitch = Mathf.Clamp(pitch - deltaY * sensitivity, -12f, 45f);
        }

        private void LateUpdate()
        {
            if (target == null) return;
            Quaternion orbit = Quaternion.Euler(pitch, target.eulerAngles.y, 0f);
            Vector3 desired = target.position + orbit * offset;
            transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * smooth);
            Vector3 lookPoint = target.position + Vector3.up * 1.25f + target.forward * 0.5f;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(lookPoint - transform.position), Time.deltaTime * smooth);
        }
    }
}
