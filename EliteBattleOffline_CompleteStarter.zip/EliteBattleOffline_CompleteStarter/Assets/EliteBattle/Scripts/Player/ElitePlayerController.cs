using UnityEngine;

namespace EliteBattle
{
    [RequireComponent(typeof(CharacterController))]
    public class ElitePlayerController : MonoBehaviour
    {
        public Transform cameraPivot;
        public float walkSpeed = 5f;
        public float sprintSpeed = 7.5f;
        public float jumpHeight = 1.3f;
        public float gravity = -20f;
        public float lookSensitivity = 2f;
        public float crouchHeight = 1.1f;
        private CharacterController controller;
        private Vector3 verticalVelocity;
        private float pitch;
        private float standingHeight;
        private bool crouched;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            standingHeight = controller.height;
            if (cameraPivot == null && Camera.main != null) cameraPivot = Camera.main.transform;
        }

        private void Update()
        {
            if (Application.isMobilePlatform)
            {
                LookByInput(MobileInput.LookDelta.x, MobileInput.LookDelta.y);
                MoveByInput(MobileInput.Move, MobileInput.SprintHeld);
                if (MobileInput.JumpPressed) Jump();
                if (MobileInput.CrouchPressed) ToggleCrouch();
                MobileInput.ConsumeOneShotActions();
                return;
            }
            float mx = Input.GetAxis("Mouse X") * lookSensitivity;
            float my = Input.GetAxis("Mouse Y") * lookSensitivity;
            LookByInput(mx, my);
            MoveByInput(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical")), Input.GetKey(KeyCode.LeftShift));
            if (Input.GetKeyDown(KeyCode.Space)) Jump();
            if (Input.GetKeyDown(KeyCode.C)) ToggleCrouch();
        }

        public void MoveByInput(Vector2 input, bool sprint)
        {
            Vector3 move = Vector3.ClampMagnitude(new Vector3(input.x, 0f, input.y), 1f);
            Vector3 direction = transform.right * move.x + transform.forward * move.z;
            controller.Move(direction * (sprint && !crouched ? sprintSpeed : walkSpeed) * Time.deltaTime);
            if (controller.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);
        }

        public void LookByInput(float deltaX, float deltaY)
        {
            ThirdPersonCamera follow = cameraPivot != null ? cameraPivot.GetComponent<ThirdPersonCamera>() : null;
            if (follow != null)
            {
                follow.AddLookInput(deltaX, deltaY);
                return;
            }
            transform.Rotate(0f, deltaX, 0f);
            pitch = Mathf.Clamp(pitch - deltaY, -35f, 65f);
            if (cameraPivot != null) cameraPivot.localRotation = Quaternion.Euler(pitch, 0f, 0f);
        }

        public void Jump()
        {
            if (controller.isGrounded) verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        public void ToggleCrouch()
        {
            crouched = !crouched;
            controller.height = crouched ? crouchHeight : standingHeight;
            controller.center = Vector3.zero;
        }
    }
}
