using UnityEngine;

namespace EliteBattle
{
    public class LootPickup : MonoBehaviour
    {
        public enum PickupType { Ammo, Medkit }
        public PickupType type = PickupType.Ammo;
        public int amount = 30;
        private void Update() { transform.Rotate(0f, 65f * Time.deltaTime, 0f); }

        private void OnTriggerEnter(Collider other)
        {
            if (!other.CompareTag("Player")) return;
            if (type == PickupType.Ammo)
            {
                WeaponShooter shooter = other.GetComponentInChildren<WeaponShooter>();
                if (shooter != null) shooter.AddAmmo(amount);
                else return;
            }
            else
            {
                Health health = other.GetComponent<Health>();
                if (health != null) health.Heal(amount);
                else return;
            }
            Destroy(gameObject);
        }
    }
}
