using UnityEngine;
using UnityEngine.EventSystems;

namespace EliteBattle
{
    // Shared input state for on-screen joystick, look zone and action buttons.
    public static class MobileInput
    {
        public static Vector2 Move;
        public static Vector2 LookDelta;
        public static bool FireHeld;
        public static bool SprintHeld;
        public static bool JumpPressed;
        public static bool CrouchPressed;
        public static bool ReloadPressed;
        public static void ConsumeOneShotActions() { JumpPressed = false; CrouchPressed = false; LookDelta = Vector2.zero; }
    }

    public class MobileJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform area;
        public RectTransform knob;
        public float radius = 70f;
        public void OnPointerDown(PointerEventData eventData) { OnDrag(eventData); }
        public void OnDrag(PointerEventData eventData)
        {
            if (area == null) area = transform as RectTransform;
            if (area == null) return;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(area, eventData.position, eventData.pressEventCamera, out Vector2 local))
            {
                Vector2 value = Vector2.ClampMagnitude(local / Mathf.Max(1f, radius), 1f);
                MobileInput.Move = value;
                if (knob != null) knob.anchoredPosition = value * radius;
            }
        }
        public void OnPointerUp(PointerEventData eventData)
        {
            MobileInput.Move = Vector2.zero;
            if (knob != null) knob.anchoredPosition = Vector2.zero;
        }
    }

    public class MobileLookZone : MonoBehaviour, IPointerDownHandler, IDragHandler
    {
        private Vector2 lastPosition;
        private bool dragging;
        public float sensitivity = 0.12f;
        public void OnPointerDown(PointerEventData eventData) { lastPosition = eventData.position; dragging = true; }
        public void OnDrag(PointerEventData eventData)
        {
            if (!dragging) return;
            Vector2 delta = eventData.position - lastPosition;
            lastPosition = eventData.position;
            MobileInput.LookDelta += delta * sensitivity;
        }
    }

    public class MobileHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
    {
        public enum ButtonAction { Fire, Sprint, Jump, Crouch, Reload }
        public ButtonAction action;
        public void OnPointerDown(PointerEventData eventData)
        {
            if (action == ButtonAction.Fire) MobileInput.FireHeld = true;
            if (action == ButtonAction.Sprint) MobileInput.SprintHeld = true;
        }
        public void OnPointerUp(PointerEventData eventData)
        {
            if (action == ButtonAction.Fire) MobileInput.FireHeld = false;
            if (action == ButtonAction.Sprint) MobileInput.SprintHeld = false;
        }
        public void OnPointerClick(PointerEventData eventData)
        {
            if (action == ButtonAction.Jump) MobileInput.JumpPressed = true;
            if (action == ButtonAction.Crouch) MobileInput.CrouchPressed = true;
            if (action == ButtonAction.Reload) MobileInput.ReloadPressed = true;
        }
    }
}
