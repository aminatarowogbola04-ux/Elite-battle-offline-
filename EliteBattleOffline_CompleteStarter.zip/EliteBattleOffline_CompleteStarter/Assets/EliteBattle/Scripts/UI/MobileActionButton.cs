using UnityEngine;

namespace EliteBattle
{
    // Attach to a UI Button's OnClick event and select an action in the Inspector.
    public class MobileActionButton : MonoBehaviour
    {
        public enum ActionType { Fire, Reload, Jump, Crouch }
        public ActionType action;
        public WeaponShooter shooter;
        public ElitePlayerController player;

        public void PerformAction()
        {
            switch (action)
            {
                case ActionType.Fire: if (shooter != null) shooter.FireOnce(); break;
                case ActionType.Reload: if (shooter != null) shooter.Reload(); break;
                case ActionType.Jump: if (player != null) player.Jump(); break;
                case ActionType.Crouch: if (player != null) player.ToggleCrouch(); break;
            }
        }
    }
}
