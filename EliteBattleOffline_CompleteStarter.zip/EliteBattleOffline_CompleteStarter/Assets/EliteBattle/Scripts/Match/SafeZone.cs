using UnityEngine;

namespace EliteBattle
{
    public class SafeZone : MonoBehaviour
    {
        public Transform zoneVisual;
        public float startRadius = 90f;
        public float finalRadius = 12f;
        public float shrinkDuration = 360f;
        public float damagePerSecondOutside = 6f;
        private float elapsed;
        private float damageTick;
        public float CurrentRadius => Mathf.Lerp(startRadius, finalRadius, Mathf.Clamp01(elapsed / Mathf.Max(1f, shrinkDuration)));

        private void Update()
        {
            elapsed += Time.deltaTime;
            if (zoneVisual != null)
            {
                float diameter = CurrentRadius * 2f;
                zoneVisual.localScale = new Vector3(diameter, 0.08f, diameter);
            }
            damageTick += Time.deltaTime;
            if (damageTick < 0.5f) return;
            float dt = damageTick;
            damageTick = 0f;
            Health[] actors = FindObjectsOfType<Health>();
            foreach (Health actor in actors)
            {
                if (actor == null || actor.IsDead) continue;
                Vector3 p = actor.transform.position - transform.position;
                if (new Vector2(p.x, p.z).magnitude > CurrentRadius) actor.TakeDamage(damagePerSecondOutside * dt);
            }
        }
    }
}
