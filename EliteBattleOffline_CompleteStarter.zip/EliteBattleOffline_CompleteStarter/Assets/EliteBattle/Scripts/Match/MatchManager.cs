using UnityEngine;
using UnityEngine.UI;

namespace EliteBattle
{
    public class MatchManager : MonoBehaviour
    {
        public Text statusText;
        private float elapsed;
        private bool ended;

        private void Update()
        {
            if (ended) return;
            elapsed += Time.deltaTime;
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            GameObject[] bots = GameObject.FindGameObjectsWithTag("Enemy");
            Health playerHealth = player != null ? player.GetComponent<Health>() : null;
            if (player == null || (playerHealth != null && playerHealth.IsDead))
            {
                ended = true;
                if (statusText != null) statusText.text = "ELIMINATED";
                return;
            }
            if (bots.Length == 0)
            {
                ended = true;
                if (statusText != null) statusText.text = "VICTORY!";
                return;
            }
            if (statusText != null) statusText.text = string.Format("ELITE BATTLE  |  BOTS: {0}  |  {1:00}:{2:00}", bots.Length, Mathf.FloorToInt(elapsed / 60f), Mathf.FloorToInt(elapsed % 60f));
        }
    }
}
