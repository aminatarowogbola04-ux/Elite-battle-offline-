#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;

namespace EliteBattle.EditorTools
{
    public static class EliteBattleSceneBuilder
    {
        private const string SceneFolder = "Assets/EliteBattle/Scenes";
        private const string ScenePath = SceneFolder + "/Prototype.unity";

        [MenuItem("Tools/Elite Battle/Create Prototype Scene")]
        public static void CreatePrototypeScene()
        {
            EnsureTag("Player");
            EnsureTag("Enemy");
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Battlefield Ground";
            ground.transform.localScale = new Vector3(20f, 1f, 20f);
            SetColor(ground, new Color(0.24f, 0.38f, 0.22f));

            CreateBlock("Warehouse A", new Vector3(14, 2, 20), new Vector3(10, 4, 8), new Color(0.35f, 0.38f, 0.42f));
            CreateBlock("Warehouse B", new Vector3(-22, 1.5f, -12), new Vector3(8, 3, 12), new Color(0.42f, 0.34f, 0.25f));
            CreateBlock("Concrete Cover 1", new Vector3(7, 1, -5), new Vector3(5, 2, 1), Color.gray);
            CreateBlock("Concrete Cover 2", new Vector3(-9, 1, 8), new Vector3(1, 2, 6), Color.gray);
            CreateBlock("Rock 1", new Vector3(27, 1.2f, -22), new Vector3(4, 2.4f, 3), new Color(0.28f, 0.29f, 0.28f));
            CreateBlock("Rock 2", new Vector3(-30, 1, 25), new Vector3(3, 2, 4), new Color(0.28f, 0.29f, 0.28f));

            GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = "Player";
            player.tag = "Player";
            player.transform.position = new Vector3(0, 1, 0);
            Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
            CharacterController cc = player.AddComponent<CharacterController>();
            cc.height = 2f;
            cc.radius = 0.42f;
            cc.center = Vector3.zero;
            player.AddComponent<Health>();
            EliteBattle.ElitePlayerController controller = player.AddComponent<EliteBattle.ElitePlayerController>();
            SetColor(player, new Color(0.1f, 0.45f, 0.9f));

            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            Camera cam = cameraObject.AddComponent<Camera>();
            cam.fieldOfView = 68f;
            cameraObject.AddComponent<AudioListener>();
            EliteBattle.ThirdPersonCamera follow = cameraObject.AddComponent<EliteBattle.ThirdPersonCamera>();
            follow.target = player.transform;
            controller.cameraPivot = cameraObject.transform;
            EliteBattle.WeaponShooter shooter = player.AddComponent<EliteBattle.WeaponShooter>();
            shooter.aimCamera = cam;

            for (int i = 0; i < 12; i++)
            {
                Vector2 point = Random.insideUnitCircle * 55f;
                if (point.magnitude < 14f) point = point.normalized * 18f;
                GameObject bot = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                bot.name = "Enemy Bot " + (i + 1);
                bot.tag = "Enemy";
                bot.transform.position = new Vector3(point.x, 1f, point.y);
                SetColor(bot, new Color(0.72f, 0.16f, 0.13f));
                bot.AddComponent<EliteBattle.Health>();
                bot.AddComponent<EliteBattle.BotAI>();
            }

            CreatePickup("Ammo Pickup A", new Vector3(5, 0.65f, 6), EliteBattle.LootPickup.PickupType.Ammo, 45);
            CreatePickup("Medkit Pickup A", new Vector3(-7, 0.65f, -4), EliteBattle.LootPickup.PickupType.Medkit, 40);
            CreatePickup("Ammo Pickup B", new Vector3(19, 0.65f, -3), EliteBattle.LootPickup.PickupType.Ammo, 45);

            GameObject zone = new GameObject("Safe Zone");
            zone.transform.position = Vector3.zero;
            EliteBattle.SafeZone safeZone = zone.AddComponent<EliteBattle.SafeZone>();
            GameObject ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ring.name = "Safe Zone Visual (prototype)";
            ring.transform.SetParent(zone.transform, false);
            ring.transform.localPosition = new Vector3(0, 0.03f, 0);
            ring.transform.localScale = new Vector3(180, 0.04f, 180);
            Collider ringCollider = ring.GetComponent<Collider>();
            if (ringCollider != null) Object.DestroyImmediate(ringCollider);
            SetColor(ring, new Color(0.1f, 0.75f, 1f, 0.25f));
            safeZone.zoneVisual = ring.transform;

            GameObject manager = new GameObject("Match Manager");
            EliteBattle.MatchManager match = manager.AddComponent<EliteBattle.MatchManager>();
            match.statusText = CreateHud();

            GameObject lightObject = new GameObject("Directional Light");
            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.1f;
            lightObject.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            if (!Directory.Exists(SceneFolder)) Directory.CreateDirectory(SceneFolder);
            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.SaveAssets();
            Selection.activeObject = player;
            EditorUtility.DisplayDialog("ELITE BATTLE", "Prototype scene created. Open the scene and press Play. This is a greybox prototype, not a finished mobile game.", "OK");
        }

        private static void CreateBlock(string name, Vector3 position, Vector3 scale, Color color)
        {
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = name;
            obj.transform.position = position;
            obj.transform.localScale = scale;
            SetColor(obj, color);
        }

        private static void CreatePickup(string name, Vector3 position, EliteBattle.LootPickup.PickupType type, int amount)
        {
            GameObject obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            obj.name = name;
            obj.transform.position = position;
            obj.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
            SetColor(obj, type == EliteBattle.LootPickup.PickupType.Ammo ? new Color(0.95f, 0.72f, 0.12f) : new Color(0.12f, 0.9f, 0.3f));
            Collider col = obj.GetComponent<Collider>();
            col.isTrigger = true;
            Rigidbody rb = obj.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            EliteBattle.LootPickup pickup = obj.AddComponent<EliteBattle.LootPickup>();
            pickup.type = type;
            pickup.amount = amount;
        }

        private static Text CreateHud()
        {
            GameObject canvasObject = new GameObject("HUD Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            Canvas canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            GameObject textObject = new GameObject("Match Status", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(canvasObject.transform, false);
            RectTransform rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0, 1);
            rect.anchorMax = new Vector2(1, 1);
            rect.pivot = new Vector2(0.5f, 1);
            rect.anchoredPosition = new Vector2(0, -18);
            rect.sizeDelta = new Vector2(-40, 55);
            Text text = textObject.GetComponent<Text>();
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = 30;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = Color.white;
            text.text = "ELITE BATTLE";
            CreateTouchControls(canvasObject.transform);
            if (Object.FindObjectOfType<UnityEngine.EventSystems.EventSystem>() == null)
                new GameObject("EventSystem", typeof(UnityEngine.EventSystems.EventSystem), typeof(UnityEngine.EventSystems.StandaloneInputModule));
            return text;
        }

        private static void CreateTouchControls(Transform canvas)
        {
            GameObject joy = CreateUIElement("Move Joystick", canvas, new Vector2(0.14f, 0.18f), new Vector2(0.14f, 0.18f), new Vector2(160, 160), new Color(0.05f, 0.08f, 0.12f, 0.42f));
            RectTransform joyRect = joy.GetComponent<RectTransform>();
            EliteBattle.MobileJoystick joystick = joy.AddComponent<EliteBattle.MobileJoystick>();
            joystick.area = joyRect;
            GameObject knob = CreateUIElement("Joystick Knob", joy.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(65, 65), new Color(0.75f, 0.82f, 0.9f, 0.7f));
            joystick.knob = knob.GetComponent<RectTransform>();

            GameObject look = CreateUIElement("Look Touch Area", canvas, new Vector2(0.52f, 0.12f), new Vector2(1f, 0.88f), Vector2.zero, new Color(1f, 1f, 1f, 0.01f));
            look.AddComponent<EliteBattle.MobileLookZone>();
            CreateActionButton(canvas, "FIRE", EliteBattle.MobileHoldButton.ButtonAction.Fire, new Vector2(0.88f, 0.25f), new Vector2(112, 112));
            CreateActionButton(canvas, "JUMP", EliteBattle.MobileHoldButton.ButtonAction.Jump, new Vector2(0.76f, 0.20f), new Vector2(76, 76));
            CreateActionButton(canvas, "CROUCH", EliteBattle.MobileHoldButton.ButtonAction.Crouch, new Vector2(0.76f, 0.10f), new Vector2(84, 60));
            CreateActionButton(canvas, "RELOAD", EliteBattle.MobileHoldButton.ButtonAction.Reload, new Vector2(0.90f, 0.42f), new Vector2(88, 58));
            CreateActionButton(canvas, "RUN", EliteBattle.MobileHoldButton.ButtonAction.Sprint, new Vector2(0.28f, 0.12f), new Vector2(78, 58));
        }

        private static GameObject CreateUIElement(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 size, Color color)
        {
            GameObject obj = new GameObject(name, typeof(RectTransform), typeof(UnityEngine.UI.Image));
            obj.transform.SetParent(parent, false);
            RectTransform rect = obj.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin; rect.anchorMax = anchorMax; rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero; rect.sizeDelta = size;
            Image image = obj.GetComponent<Image>(); image.color = color; image.raycastTarget = true;
            return obj;
        }

        private static void CreateActionButton(Transform canvas, string label, EliteBattle.MobileHoldButton.ButtonAction action, Vector2 anchor, Vector2 size)
        {
            GameObject button = CreateUIElement(label + " Button", canvas, anchor, anchor, size, new Color(0.05f, 0.1f, 0.16f, 0.72f));
            button.AddComponent<EliteBattle.MobileHoldButton>().action = action;
            GameObject textObject = new GameObject(label + " Label", typeof(RectTransform), typeof(Text));
            textObject.transform.SetParent(button.transform, false);
            RectTransform rect = textObject.GetComponent<RectTransform>(); rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one; rect.offsetMin = Vector2.zero; rect.offsetMax = Vector2.zero;
            Text text = textObject.GetComponent<Text>(); text.font = Resources.GetBuiltinResource<Font>("Arial.ttf"); text.text = label; text.fontSize = 18; text.alignment = TextAnchor.MiddleCenter; text.color = Color.white; text.raycastTarget = false;
        }

        private static void SetColor(GameObject obj, Color color)
        {
            Renderer renderer = obj.GetComponent<Renderer>();
            if (renderer == null) return;
            Material material = new Material(Shader.Find("Standard"));
            material.color = color;
            renderer.sharedMaterial = material;
        }

        private static void EnsureTag(string tag)
        {
            if (System.Array.IndexOf(UnityEditorInternal.InternalEditorUtility.tags, tag) >= 0) return;
            UnityEditorInternal.InternalEditorUtility.AddTag(tag);
        }
    }
}
#endif
